/**********************************/
/* TIPOS DE DATOS ==> Ejercicios */
/*********************************/
// 1. ¿Cuál es el resultado de la siguiente expresión?
// typeof null

// 2. ¿Cuál es el resultado de la siguiente expresión?
// typeof undefined

// 3. ¿Cuál es el resultado de la siguiente expresión?
// typeof 0

// 4. ¿Qué valor devuelve la siguiente expresión?
// 'hola' + 'mundo'

// 5. ¿Qué valor devuelve la siguiente expresión?
// 'hola' + ' ' + 'mundo'

// 6. ¿Qué valor devuelve la siguiente expresión?
// 'hola' + 5

// 7. ¿Qué valor devuelve la siguiente expresión?
// 'hola'[3]

// 8. ¿Qué valor devuelve la siguiente expresión?
// `El resultado de la operación entre 4 + 5 es ${4 + 5}`

// 9. ¿Qué tipo de dato es el siguiente valor?
// typeof NaN

// 10. ¿Qué tipo de dato es el siguiente valor?
// typeof false
